package org.example.tds.td6.filesystem.business.api.structure.identification;

/**
 * Identification de fichier.
 */
public interface FileId extends Id<Integer> {
    
}
