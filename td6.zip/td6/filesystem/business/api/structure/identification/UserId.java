package org.example.tds.td6.filesystem.business.api.structure.identification;

/**
 * Identification d'utilisateur.
 */
public interface UserId extends Id<Integer> {
    
}
