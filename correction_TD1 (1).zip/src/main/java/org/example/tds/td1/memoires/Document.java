package org.example.tds.td1.memoires;

public interface Document {
    public String titre();
    public int taille();
}
