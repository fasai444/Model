Noter ici l'organisation en paquetages qui devient importante.
On a :
- le code métier, séparé des clients (gestion Factory)
- les api (interfaces), séparées des implémentations

Cela a conduit entre autres à introduire une interface ICard pour bien séparer abstractions et implémentations.