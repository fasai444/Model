package org.example.tds.td4.sechoir.api;

public class ActionIllegale extends Exception {
    public ActionIllegale(String message) {
        super(message);
    }
}
