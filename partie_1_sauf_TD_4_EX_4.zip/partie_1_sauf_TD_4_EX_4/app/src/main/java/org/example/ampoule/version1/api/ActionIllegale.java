package org.example.ampoule.version1.api;

public class ActionIllegale extends Exception {
    public ActionIllegale(String info) {
        super(info);
    }
}
