package org.example.cards.cours3;

public class App {
    public static void main(String[] args) {
        // simple car on a aussi des tests !
        // (probable qu'on ne fera pas d'App systématiquement dans la suite)
        Deck deck = new Deck();
        System.out.println(deck);
    }
}
