package org.example.tds.td4.ampoule.version1.api;

public class ActionIllegale extends Exception {
    public ActionIllegale(String info) {
        super(info);
    }
}
