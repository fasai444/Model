package org.example.ampoule.version2.api;

public class ActionIllegale extends Exception {
    public ActionIllegale(String info) {
        super(info);
    }
}
