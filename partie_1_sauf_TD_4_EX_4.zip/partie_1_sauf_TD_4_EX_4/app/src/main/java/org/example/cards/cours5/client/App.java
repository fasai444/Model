package org.example.cards.cours5.client;

public class App {

    public static void main(String[] args) {
        // ICard card = null;
        // System.out.println(card.rank());
        // Exception in thread "main" java.lang.NullPointerException: Cannot invoke "org.example.cards.cours5.metier.api.ICard.rank()" because "card" is null
    }
}
