package org.example.tds.td5.filesystem.business.api.structure.identification;

/**
 * Identification d'utilisateur.
 */
public interface UserId extends Id<Integer> {
    
}
